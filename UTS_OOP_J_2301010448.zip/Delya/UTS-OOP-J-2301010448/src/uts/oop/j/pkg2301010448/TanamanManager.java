package uts.oop.j.pkg2301010448;

public class TanamanManager {
    private Tanaman[] tanamans;
    private int count;

    public TanamanManager(int size) {
        tanamans = new Tanaman[size];
        count = 0;
    }

    public void tambahTanaman(Tanaman tanaman) {
        if (count < tanamans.length) {
            tanamans[count] = tanaman;
            count++;
        } else {
            System.out.println("Array penuh, tidak bisa menambah data tanaman.");
        }
    }

    public void tampilkanTanamans() {
        if (count == 0) {
            System.out.println("Belum ada data tanaman.");
        } else {
            for (int i = 0; i < count; i++) {
                System.out.println(tanamans[i]);
            }
        }
    }

    public void ubahTanaman(int id, String namaBaru, String jenisBaru, String deskripsiBaru) {
        boolean ditemukan = false;
        for (int i = 0; i < count; i++) {
            if (tanamans[i].getId() == id) {
                tanamans[i].setNama(namaBaru);
                tanamans[i].setJenis(jenisBaru);
                tanamans[i].setDeskripsi(deskripsiBaru);
                ditemukan = true;
                System.out.println("Data tanaman berhasil diubah.");
                break;
            }
        }
        if (!ditemukan) {
            System.out.println("Tanaman dengan ID " + id + " tidak ditemukan.");
        }
    }

    public void hapusTanaman(int id) {
        boolean ditemukan = false;
        for (int i = 0; i < count; i++) {
            if (tanamans[i].getId() == id) {
                // Geser array untuk hapus data
                for (int j = i; j < count - 1; j++) {
                    tanamans[j] = tanamans[j + 1];
                }
                tanamans[count - 1] = null;
                count--;
                ditemukan = true;
                System.out.println("Data tanaman berhasil dihapus.");
                break;
            }
        }
        if (!ditemukan) {
            System.out.println("Tanaman dengan ID " + id + " tidak ditemukan.");
        }
    }
}
