package uts.oop.j.pkg2301010448;

import java.util.Scanner;

public class UTSOOPJ2301010448 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TanamanManager tanamanManager = new TanamanManager(100);

        int pilihan;
        do {
            System.out.println("\n--- Aplikasi Data Tanaman ---");
            System.out.println("1. Tambah Data Tanaman");
            System.out.println("2. Tampilkan Data Tanaman");
            System.out.println("3. Ubah Data Tanaman");
            System.out.println("4. Hapus Data Tanaman");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Input harus angka. Silakan coba lagi.");
                scanner.next(); // buang input yang salah
            }
            pilihan = scanner.nextInt();
            scanner.nextLine(); // biar nggak dilewati

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan ID Tanaman: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Masukkan Nama Tanaman: ");
                    String nama = scanner.nextLine();
                    System.out.print("Masukkan Jenis Tanaman: ");
                    String jenis = scanner.nextLine();
                    System.out.print("Masukkan Deskripsi: ");
                    String deskripsi = scanner.nextLine();
                    Tanaman tanaman = new Tanaman(id, nama, jenis, deskripsi);
                    tanamanManager.tambahTanaman(tanaman);
                    break;
                case 2:
                    tanamanManager.tampilkanTanamans();
                    break;
                case 3:
                    System.out.print("Masukkan ID Tanaman yang ingin diubah: ");
                    int idUbah = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Masukkan Nama Baru: ");
                    String namaBaru = scanner.nextLine();
                    System.out.print("Masukkan Jenis Baru: ");
                    String jenisBaru = scanner.nextLine();
                    System.out.print("Masukkan Deskripsi Baru: ");
                    String deskripsiBaru = scanner.nextLine();
                    tanamanManager.ubahTanaman(idUbah, namaBaru, jenisBaru, deskripsiBaru);
                    break;
                case 4:
                    System.out.print("Masukkan ID Tanaman yang ingin dihapus: ");
                    int idHapus = scanner.nextInt();
                    tanamanManager.hapusTanaman(idHapus);
                    break;
                case 5:
                    System.out.println("Keluar dari aplikasi.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 5);

        scanner.close(); // biar rapi
    }
}
