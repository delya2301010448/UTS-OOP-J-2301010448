package uts.oop.j.pkg2301010448;

public class Tanaman {
    private int id;
    private String nama;
    private String jenis;
    private String deskripsi;

    // Constructor
    public Tanaman(int id, String nama, String jenis, String deskripsi) {
        this.id = id;
        this.nama = nama;
        this.jenis = jenis;
        this.deskripsi = deskripsi;
    }

    // Getter & Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nama: " + nama + ", Jenis: " + jenis + ", Deskripsi: " + deskripsi;
    }
}
